package Logica;

public class JugadorCardDraw extends Jugador {


}
