package Logica;

import java.util.ArrayList;

public abstract class Jugador {
    ArrayList<Carta> cartasBocaArriba;
    ArrayList<Carta> cartasBocaAbajo;
}
