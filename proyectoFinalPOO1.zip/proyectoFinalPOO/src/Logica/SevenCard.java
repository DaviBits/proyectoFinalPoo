package Logica;

public class SevenCard extends Poker {


    public SevenCard() {
        super();
    }

    @Override
    public void repartirCartas() {

    }

    @Override
    public void empezarApuestas() {

    }

    @Override
    public void comenzarEnfrentamiento() {

    }

}
