package Logica;

public class JugadorSevenCard extends Jugador {
}
